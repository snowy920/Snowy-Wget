# 软件版本，请不要修改
VERSION = '1.0-ALPHA'

# 服务器信息
SERVER_INFO = {
    '1dd454c7-42b0-4059-a2b4-cd16f0ac9085':
        {'name': '测试', 'cpu_precent': 0, 'memory': 0, 'memory_all': 0, 'update_time': 0, 'uptime': 0, 'load': '',
         'network_in': 0, 'network_out': 0, 'traffic_in': 0, 'traffic_out': 0, 'hdd': 0, 'hdd_all': 0,
         'token': '123456'},
}
# 请自行修改
SECRET_KEY = 'b7q%nqtI%kBoP@Fd'
